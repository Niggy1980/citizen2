import 'package:flutter/material.dart';



class ReGister extends StatelessWidget {
  const ReGister({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: (
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("register")
            ],
          )
          ),
        ),
      ),
    );
  }
}
