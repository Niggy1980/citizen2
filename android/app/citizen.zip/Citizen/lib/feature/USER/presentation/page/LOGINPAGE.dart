import 'package:citizen/feature/USER/presentation/page/Register.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: Colors.blueAccent,
            title: Center(
              child: Text("Citizen Complaint",
                style: TextStyle(
                    fontSize: 30,
                    color: Colors.white,
                    fontWeight: FontWeight.bold
                ),),
            ),
          ),
          body: Center(
            child: (
                Column(
                  children: [
                    Padding(padding: EdgeInsets.only(top: 100)),
                    Container(child: Image(image: AssetImage('assets/image/LOG.png'),width: 150,),),
                    SizedBox(
                      height: 30,
                    ),
                    Text("Welcome",style: TextStyle(
                      fontSize: 40,),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right:300,left: 250,top: 100,),
                      child: TextField(
                          decoration: InputDecoration(border: OutlineInputBorder(),
                              icon: Icon(Icons.account_circle,color: Colors.blue,size: 40,),
                              hintText: "Enter your ID..")
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right:300,left: 250,top: 20,),
                      child: TextField(
                          decoration: InputDecoration(border: OutlineInputBorder(),
                              icon: Icon(Icons.key,color: Colors.blue,size: 40,),
                              hintText: "Enter your Password..")
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 280,top: 10),
                      child: Container(
                        child: TextButton(
                          onPressed: (){Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => ReGister()),
                          );},
                          child: Text("register"),
                        ),
                      )
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      decoration: BoxDecoration(color: Colors.lightBlue,borderRadius: BorderRadius.circular(12)),
                      padding: EdgeInsets.only(left: 25,right: 25,top: 10,bottom: 10),
                      child: const Text("Login",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                )
            ),
          )
      ),
    );
  }
}
